/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    float miles;//total miles traveled
    float lit;//the total liters used
    float galls;//gallons
    //Declare Variables
    
    //Initialize or input i.e. set variable values
    galls=  miles/(lit * galls);
    //Map inputs -> outputs
    cout<<"Enter number of liters of gasoline:"<<endl;
    cin>>lit;
    cout<<endl;
    cout<<"Enter number of miles traveled:"<<endl;
    cin>>miles;
    cout<<endl;
    cout<<"miles per gallon:"<<endl;
    cin>>galls;
    cout<< galls <<endl;
    cout<<"Again:"<<endl;
    cout<<"To continue, then enter 'Y' :";
    cin>> option;
    {while (options =='y' || options == 'Y');
    
    
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}