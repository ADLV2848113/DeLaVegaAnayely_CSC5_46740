/*
 * File:   main.cpp
 * Author: Anayely De La Vega
 * Created on June 27, 2020, 2:59 PM
 * Purpose: It will display a diamond.
 */

//System Libraries
#include <iostream> //I/O Library
using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical and Laboratory Constants

//Function Prototypes 

//Execution of Code Begins Here
int main(int argc, char** argv) {
    //Set the random number seed here
    
    //Declare all variables for this function
    
    //Initialize all known variables 
    
    //Process Inputs to Outputs -> Mapping Process
    //Maps known values to the unknown objectives 
    
    //Display the Inputs/Outputs
    cout<< "   *   " <<endl;
    cout<< "  ***  " <<endl;
    cout<< " ***** " <<endl;
    cout<< "*******" <<endl;
    cout<< " ***** " <<endl;
    cout<< "  ***  " <<endl;
    cout<< "   *   " <<endl;
    
    
    //Clean up the code, close files. deallocate memory, etc...
    //Exit stage right 
    return 0;
}

